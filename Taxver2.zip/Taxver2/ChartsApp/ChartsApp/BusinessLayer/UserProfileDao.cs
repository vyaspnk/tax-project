﻿using BusinessLayer.BusinessObjects;
using BusinessLayer.DataBase;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer
{
    public class UserProfileDao
    {
        private DBAccess objDBAccess = DBAccess.Instance;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="objEmploymentDetailsEntity"></param>
        /// <returns></returns>
        public bool SetEmploymentDetails(EmploymentDetailsEntity objEmploymentDetailsEntity)
        {
            bool status = false;
            try
            {
                List<ParameterList> objParameterList = new List<ParameterList>();

                objParameterList.Add(new ParameterList { ParameterName = "@_EmploymentDetailsID", ParameterValue = objEmploymentDetailsEntity.EmploymentDetailsID == null ? "0" : objEmploymentDetailsEntity.EmploymentDetailsID.ToString() });

                objParameterList.Add(new ParameterList { ParameterName = "@_UserID", ParameterValue = Convert.ToString(objEmploymentDetailsEntity.UserID) });
                objParameterList.Add(new ParameterList { ParameterName = "@_CompanyName", ParameterValue = Convert.ToString(objEmploymentDetailsEntity.CompanyName) });
                objParameterList.Add(new ParameterList { ParameterName = "@_GrossPay", ParameterValue = Convert.ToString(objEmploymentDetailsEntity.GrossPay) });
                objParameterList.Add(new ParameterList { ParameterName = "@_Bonus", ParameterValue = Convert.ToString(objEmploymentDetailsEntity.Bonus) });
                objParameterList.Add(new ParameterList { ParameterName = "@_PayFrequencyID", ParameterValue = Convert.ToString(objEmploymentDetailsEntity.PayFrequencyID) });
                objParameterList.Add(new ParameterList { ParameterName = "@_EmpStartDate", ParameterValue = objEmploymentDetailsEntity.EmpStartDate.ToDateTimeFormat() });
                objParameterList.Add(new ParameterList { ParameterName = "@_EmpEndDate", ParameterValue =  objEmploymentDetailsEntity.EmpEndDate.ToDateTimeFormat() });
                objParameterList.Add(new ParameterList { ParameterName = "@_IsActive", ParameterValue = Convert.ToString(objEmploymentDetailsEntity.IsActive ? "0" : "1") });
                objParameterList.Add(new ParameterList { ParameterName = "@_IsDeleted", ParameterValue = Convert.ToString(objEmploymentDetailsEntity.IsDeleted ? "0" : "1") });

                status = objDBAccess.ExecuteStoreProcedure("SetEmploymentDetails", objParameterList);
                return status;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }


        public bool SetUser401kDetails(User401kDetailsEntity objUser401kDetailsEntity)
        {
            bool status = false;
            try
            {
                List<ParameterList> objParameterList = new List<ParameterList>();

                objParameterList.Add(new ParameterList { ParameterName = "@_User401kDetailsID", ParameterValue = objUser401kDetailsEntity.User401kDetailsID == null ? "0" : objUser401kDetailsEntity.User401kDetailsID.ToString() });
                objParameterList.Add(new ParameterList { ParameterName = "@_UserID", ParameterValue = Convert.ToString(objUser401kDetailsEntity.UserID) });
                objParameterList.Add(new ParameterList { ParameterName = "@_CurrentContributionPersentage", ParameterValue = Convert.ToString(objUser401kDetailsEntity.CurrentContributionPersentage) });
                objParameterList.Add(new ParameterList { ParameterName = "@_Current401kBalance", ParameterValue = Convert.ToString(objUser401kDetailsEntity.Current401kBalance) });
                objParameterList.Add(new ParameterList { ParameterName = "@_EmployerMatchPersentage", ParameterValue = Convert.ToString(objUser401kDetailsEntity.EmployerMatchPersentage) });
                objParameterList.Add(new ParameterList { ParameterName = "@_EmployerMatchEndPersentage", ParameterValue = Convert.ToString(objUser401kDetailsEntity.EmployerMatchEndPersentage) });
                objParameterList.Add(new ParameterList { ParameterName = "@_IsActive", ParameterValue = Convert.ToString(objUser401kDetailsEntity.IsActive ? "0" : "1") });
                objParameterList.Add(new ParameterList { ParameterName = "@_IsDeleted", ParameterValue = Convert.ToString(objUser401kDetailsEntity.IsDeleted ? "0" : "1") });

                status = objDBAccess.ExecuteStoreProcedure("SetUser401kDetails", objParameterList);
                return status;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool SetBankDetails(BankDetailsEntity objUserBankDetailsEntity)
        {
            bool status = false;
            try
            {
                List<ParameterList> objParameterList = new List<ParameterList>();

                objParameterList.Add(new ParameterList { ParameterName = "@_UserBankDetailsID", ParameterValue = objUserBankDetailsEntity.UserBankDetailsID == 0 ? "0" : objUserBankDetailsEntity.UserBankDetailsID.ToString() });
                objParameterList.Add(new ParameterList { ParameterName = "@_UserID", ParameterValue = Convert.ToString(objUserBankDetailsEntity.UserID) });
                objParameterList.Add(new ParameterList { ParameterName = "@_BankName", ParameterValue = Convert.ToString(objUserBankDetailsEntity.BankName) });
                objParameterList.Add(new ParameterList { ParameterName = "@_AccountName", ParameterValue = Convert.ToString(objUserBankDetailsEntity.AccountName) });
                objParameterList.Add(new ParameterList { ParameterName = "@_AccountBalance", ParameterValue = Convert.ToString(objUserBankDetailsEntity.AccountBalance) });                
                objParameterList.Add(new ParameterList { ParameterName = "@_Type", ParameterValue = Convert.ToString(objUserBankDetailsEntity.Type) });
               // objParameterList.Add(new ParameterList { ParameterName = "@_IsActive", ParameterValue = Convert.ToString((objUserBankDetailsEntity.IsActive ? "1" : "0")) });
                //objParameterList.Add(new ParameterList { ParameterName = "@_ModifiedDate", ParameterValue = Convert.ToString(objUserBankDetailsEntity.ModifiedDate) });


                status = objDBAccess.ExecuteStoreProcedure("SetBankDetails", objParameterList);
                return status;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        
        public List<EmploymentDetailsEntity> GetEmploymentDetailsByUserID(int userID)
        {
            try
            {
                List<ParameterList> objParameterList = new List<ParameterList>();
                objParameterList.Add(new ParameterList { ParameterName = "_UserID", ParameterValue = userID.ToString() });
                DataTable dt = objDBAccess.GetStoreProcedureDataTable("GetEmploymentDetailsByUserID", objParameterList);
                if (dt.Rows.Count > 0)
                {
                    List<EmploymentDetailsEntity> objListEmploymentDetails = new List<EmploymentDetailsEntity>();
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        objListEmploymentDetails.Add(new EmploymentDetailsEntity
                        {
                            EmploymentDetailsID = Convert.ToInt32(dt.Rows[i]["EmploymentDetailsID"]),
                            UserID = Convert.ToInt32(dt.Rows[i]["UserID"]),
                            CompanyName = Convert.ToString(dt.Rows[i]["CompanyName"]),
                            GrossPay = Convert.ToDecimal(dt.Rows[i]["GrossPay"]),
                            Bonus = Convert.ToDecimal(dt.Rows[i]["Bonus"]),
                            PayFrequencyID = Convert.ToInt32(dt.Rows[i]["PayFrequencyID"]),
                            EmpStartDate = Convert.ToDateTime(dt.Rows[0]["EmpStartDate"].ToString() == "" ? null : dt.Rows[0]["EmpStartDate"]),
                            EmpEndDate = Convert.ToDateTime(dt.Rows[0]["EmpEndDate"].ToString() == "" ? null : dt.Rows[0]["EmpEndDate"])

                        });
                    }
                    return objListEmploymentDetails;
                }
                else
                {
                    return null;
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public List<User401kDetailsEntity> GetUser401kDetailsByUserID(int userID)
        {
            try
            {
                List<ParameterList> objParameterList = new List<ParameterList>();
                objParameterList.Add(new ParameterList { ParameterName = "_UserID", ParameterValue = userID.ToString() });
                DataTable dt = objDBAccess.GetStoreProcedureDataTable("GetUser401kDetailsByUserID", objParameterList);
                if (dt.Rows.Count > 0)
                {
                    List<User401kDetailsEntity> objUser401kDetailsEntity = new List<User401kDetailsEntity>();
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        objUser401kDetailsEntity.Add(new User401kDetailsEntity
                        {
                            User401kDetailsID = Convert.ToInt32(dt.Rows[i]["User401kDetailsID"]),
                            UserID = Convert.ToInt32(dt.Rows[i]["UserID"]),
                            CurrentContributionPersentage = Convert.ToInt32(dt.Rows[i]["CurrentContributionPersentage"]),
                            Current401kBalance = Convert.ToDecimal(dt.Rows[i]["Current401kBalance"]),
                            EmployerMatchPersentage = Convert.ToInt32(dt.Rows[i]["EmployerMatchPersentage"]),
                            EmployerMatchEndPersentage = Convert.ToInt32(dt.Rows[i]["EmployerMatchEndPersentage"]) 

                        });
                    }
                    return objUser401kDetailsEntity;
                }
                else
                {
                    return null;
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public List<BankDetailsEntity> GetBankDetailsByUserID(int userID)
        {
            try
            {
                List<ParameterList> objParameterList = new List<ParameterList>();
                objParameterList.Add(new ParameterList { ParameterName = "_UserID", ParameterValue = userID.ToString() });
                DataTable dt = objDBAccess.GetStoreProcedureDataTable("GetBankDetailsByUserID", objParameterList);
                if (dt.Rows.Count > 0)
                {
                    List<BankDetailsEntity> objUserBankDetails = new List<BankDetailsEntity>();
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        objUserBankDetails.Add(new BankDetailsEntity
                        {
                            UserBankDetailsID = Convert.ToInt32(dt.Rows[i]["UserBankDetailsID"]),
                            UserID = Convert.ToInt32(dt.Rows[i]["UserID"]),
                            BankName = Convert.ToString(dt.Rows[i]["BankName"]),
                            AccountName = Convert.ToString(dt.Rows[i]["AccountName"]),
                            AccountBalance = Convert.ToDecimal(dt.Rows[i]["AccountBalance"]),
                            Type = Convert.ToInt32(dt.Rows[i]["Type"]),
                            //ModifiedDate = Convert.ToDateTime(dt.Rows[i]["ModifiedDate"].ToString() == "" ? null : dt.Rows[i]["ModifiedDate"]),
                            //IsActive = Convert.ToBoolean(1)// Convert.ToBoolean(dt.Rows[i]["IsActive"])
                        });
                    }
                    return objUserBankDetails;
                }
                else
                {
                    return null;
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
       
        public Dictionary<string, string> GetPayFrequencyDetails()
        {
            Dictionary<string, string> obj = new Dictionary<string, string>();
            try
            {
                List<ParameterList> objParameterList = new List<ParameterList>();
                //objParameterList.Add(new ParameterList { ParameterName = "_UserID", ParameterValue = userID.ToString() });
                DataTable dt = objDBAccess.GetStoreProcedureDataTable("GetPayFrequency", objParameterList);
                if (dt.Rows.Count > 0)
                {
                    List<EmploymentDetailsEntity> objListEmploymentDetails = new List<EmploymentDetailsEntity>();
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {

                        obj.Add(Convert.ToString(dt.Rows[i]["PayFrequencyID"]), Convert.ToString(dt.Rows[i]["PayFrequency"]));
                         
                    }
                    return obj;
                }
                else
                {
                    return null;
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }




    }
}
