﻿using BusinessLayer.BusinessObjects;
using BusinessLayer.DataBase;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer
{
    public class AccountsDao
    {
        private DBAccess objDBAccess = DBAccess.Instance;
        public bool SaveAccountDetails(AccountEntity objUserAccountEntity)
        {
            bool status = false;
            try
            {
                List<ParameterList> objParameterList = new List<ParameterList>();

                objParameterList.Add(new ParameterList { ParameterName = "@_AccountDetailsID", ParameterValue = objUserAccountEntity.AccountDetailsID == 0 ? "0" : objUserAccountEntity.AccountDetailsID.ToString() });
                objParameterList.Add(new ParameterList { ParameterName = "@_UserID", ParameterValue = Convert.ToString(objUserAccountEntity.UserID) });
                objParameterList.Add(new ParameterList { ParameterName = "@_AccountName", ParameterValue = Convert.ToString(objUserAccountEntity.AccountName) });
                objParameterList.Add(new ParameterList { ParameterName = "@_AccountDetailsObj", ParameterValue = Convert.ToString(objUserAccountEntity.AccountDetailsObj) });
                objParameterList.Add(new ParameterList { ParameterName = "@_Type", ParameterValue = Convert.ToString(objUserAccountEntity.Type) });

                status = objDBAccess.ExecuteStoreProcedure("SaveAccountDetails", objParameterList);
                return status;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public bool DeleteAccountDetails(AccountEntity objUserAccountEntity)
        {
            bool status = false;
            try
            {
                List<ParameterList> objParameterList = new List<ParameterList>();

                objParameterList.Add(new ParameterList { ParameterName = "@_AccountDetailsID", ParameterValue = objUserAccountEntity.AccountDetailsID == 0 ? "0" : objUserAccountEntity.AccountDetailsID.ToString() });
                objParameterList.Add(new ParameterList { ParameterName = "@_UserID", ParameterValue = Convert.ToString(objUserAccountEntity.UserID) });
                //objParameterList.Add(new ParameterList { ParameterName = "@_AccountName", ParameterValue = Convert.ToString(objUserAccountEntity.AccountName) });
                //objParameterList.Add(new ParameterList { ParameterName = "@_AccountDetailsObj", ParameterValue = Convert.ToString(objUserAccountEntity.AccountDetailsObj) });
                //objParameterList.Add(new ParameterList { ParameterName = "@_Type", ParameterValue = Convert.ToString(objUserAccountEntity.Type) });

                status = objDBAccess.ExecuteStoreProcedure("DeleteAccountDetailsByAccountID", objParameterList);
                return status;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public List<AccountEntity> GetAccountDetailsByUserID(int userID)
        {
            try
            {
                List<ParameterList> objParameterList = new List<ParameterList>();
                objParameterList.Add(new ParameterList { ParameterName = "_UserID", ParameterValue = userID.ToString() });
                DataTable dt = objDBAccess.GetStoreProcedureDataTable("GetAccountDetailsByUserID", objParameterList);
                if (dt.Rows.Count > 0)
                {
                    List<AccountEntity> objAccountDetailsList = new List<AccountEntity>();
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        objAccountDetailsList.Add(new AccountEntity
                        {
                            AccountDetailsID = Convert.ToInt32(dt.Rows[i]["AccountDetailsID"]),
                            UserID = Convert.ToInt32(dt.Rows[i]["UserID"]),
                            AccountName = Convert.ToString(dt.Rows[i]["AccountName"]),
                            AccountDetailsObj = Convert.ToString(dt.Rows[i]["AccountDetails"]),
                            Type = Convert.ToInt32(dt.Rows[i]["Type"])
                        });
                    }
                    return objAccountDetailsList;
                }
                else
                {
                    return null;
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
