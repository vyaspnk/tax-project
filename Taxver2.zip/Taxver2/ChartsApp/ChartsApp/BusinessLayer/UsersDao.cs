﻿using BusinessLayer.BusinessObjects;
using BusinessLayer.DataBase;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer
{
    /// <summary>
    /// 
    /// </summary>
    public class UsersDao
    {
        private DBAccess objDBAccess = DBAccess.Instance;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="objUserEntity"></param>
        /// <returns></returns>
        public bool RegisterUserDetails(UserEntity objUserEntity)
        {
            bool status = false;
            try
            {
                List<ParameterList> objParameterList = new List<ParameterList>();


                objParameterList.Add(new ParameterList { ParameterName = "@_UserID", ParameterValue = objUserEntity.UserID == 0 ? "0" : objUserEntity.UserID.ToString() });
                objParameterList.Add(new ParameterList { ParameterName = "@_LoginID", ParameterValue = objUserEntity.LoginID });
                objParameterList.Add(new ParameterList { ParameterName = "@_LoginPassword", ParameterValue = objUserEntity.LoginPassword });
                objParameterList.Add(new ParameterList { ParameterName = "@_Email", ParameterValue = objUserEntity.Email });
                objParameterList.Add(new ParameterList { ParameterName = "@_Phone", ParameterValue = objUserEntity.Phone });
                objParameterList.Add(new ParameterList { ParameterName = "@_FirstName", ParameterValue = objUserEntity.FirstName });
                objParameterList.Add(new ParameterList { ParameterName = "@_LastName", ParameterValue = objUserEntity.LastName });
                objParameterList.Add(new ParameterList { ParameterName = "@_Company", ParameterValue = objUserEntity.Company });
                objParameterList.Add(new ParameterList { ParameterName = "@_IsActive", ParameterValue = Convert.ToString(objUserEntity.IsActive ? "0" : "1") });
                objParameterList.Add(new ParameterList { ParameterName = "@_IsDeleted", ParameterValue = Convert.ToString(objUserEntity.IsDeleted ? "0" : "1") });
                objParameterList.Add(new ParameterList { ParameterName = "@_Gender", ParameterValue = Convert.ToString(objUserEntity.Gender) });
                objParameterList.Add(new ParameterList { ParameterName = "@_BirthDate", ParameterValue =objUserEntity.BirthDate.ToDateTimeFormat() });
                status = objDBAccess.ExecuteStoreProcedure("SetUserDetails", objParameterList);
                return status;
            }
            catch (Exception ex)
            {
                
                throw ex;
            }
        }

        public UserEntity ValidateUser(int userID, string loginID, string pwd)
        {
            try
            {
                List<ParameterList> objParameterList = new List<ParameterList>();

                objParameterList.Add(new ParameterList { ParameterName = "@_LoginID", ParameterValue = loginID });
                objParameterList.Add(new ParameterList { ParameterName = "@_LoginPassWord", ParameterValue = pwd });

                DataTable dt = objDBAccess.GetStoreProcedureDataTable("ValidateUser", objParameterList);
                if (dt.Rows.Count > 0)
                {
                    UserEntity objUserEntity = new UserEntity();

                    objUserEntity.UserID = Convert.ToInt32(dt.Rows[0]["UserID"]);
                    objUserEntity.LoginID = Convert.ToString(dt.Rows[0]["LoginID"]);
                    objUserEntity.FirstName = Convert.ToString(dt.Rows[0]["FirstName"]);
                    objUserEntity.LastName = Convert.ToString(dt.Rows[0]["LastName"]);
                    objUserEntity.Company = Convert.ToString(dt.Rows[0]["Company"]);
                    objUserEntity.LoginPassword = Convert.ToString(dt.Rows[0]["LoginPassword"]);
                    objUserEntity.Email = Convert.ToString(dt.Rows[0]["Email"]);
                    objUserEntity.Phone = Convert.ToString(dt.Rows[0]["Phone"]);
                    objUserEntity.BirthDate = Convert.ToDateTime(dt.Rows[0]["BirthDate"]);
                    objUserEntity.ModifiedDate = Convert.ToDateTime(dt.Rows[0]["ModifiedDate"].ToString() == "" ? null : dt.Rows[0]["ModifiedDate"]);
                    objUserEntity.LastLoginDate = Convert.ToDateTime(dt.Rows[0]["LastLoginDate"]);
                    objUserEntity.Gender = Convert.ToChar(dt.Rows[0]["Gender"]);
                    return objUserEntity;
                }
                else
                {
                    return null;

                }

                //objParameterList.ID = 0;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable GetMenuItems()
        {
            try
            {
                List<ParameterList> objParameterList = new List<ParameterList>();
                return objDBAccess.GetStoreProcedureDataTable("GetMenuItems", objParameterList);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


    }
}
