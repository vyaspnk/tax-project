﻿using BusinessLayer.BusinessObjects;
using BusinessLayer.DataBase;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer
{
    /// <summary>
    /// 
    /// </summary>
    public class StockTransactionDao
    {
        private DBAccess objDBAccess = DBAccess.Instance;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="UserID"></param>
        /// <returns></returns>
        public List<StockTransactionsEntity> GetStockTransactionsByUserID(int UserID)
        {
            try
            {
                List<ParameterList> objParameterList = new List<ParameterList>();
                objParameterList.Add(new ParameterList { ParameterName = "_UserID", ParameterValue = UserID.ToString() });
                DataTable dt = objDBAccess.GetStoreProcedureDataTable("GetStockTransactionsByUserID", objParameterList);
                if (dt.Rows.Count > 0)
                {
                    List<StockTransactionsEntity> objStockTransactionsEntiry = new List<StockTransactionsEntity>();
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {

                        objStockTransactionsEntiry.Add(new StockTransactionsEntity
                        {
                            StockTransactionsID = Convert.ToInt32(dt.Rows[i]["StockTransactionsID"]),
                            UserID = Convert.ToInt32(dt.Rows[i]["UserID"]),
                            Symbol = Convert.ToString(dt.Rows[i]["Symbol"]),
                            TypeID = Convert.ToInt32(dt.Rows[i]["TypeID"]),
                            Date = DateTime.Parse(Convert.ToString(dt.Rows[i]["Date"])),
                            Shares = Convert.ToDecimal(dt.Rows[i]["Shares"]),
                            Price = Convert.ToDecimal(dt.Rows[i]["Price"]),
                            Commmission = Convert.ToDecimal(dt.Rows[i]["Commmission"]),
                            Notes = Convert.ToString(dt.Rows[i]["Notes"]),
                            TransactionType = Convert.ToString(dt.Rows[i]["TransactionType"]),
                            BrokerageCompanyName = Convert.ToString(dt.Rows[i]["BrokerageCompanyName"]) 
                        });
                    }
                    return objStockTransactionsEntiry;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="objStockTransactionsEntiry"></param>
        /// <returns></returns>
        public bool SetStockTransactions(StockTransactionsEntity objStockTransactionsEntiry)
        {
            bool status = false;
            try
            {

                List<ParameterList> objParameterList = new List<ParameterList>();

                objParameterList.Add(new ParameterList { ParameterName = "_stockTransactionsID", ParameterValue = objStockTransactionsEntiry.StockTransactionsID.ToString() });//🌐
                objParameterList.Add(new ParameterList { ParameterName = "_UserID", ParameterValue = objStockTransactionsEntiry.UserID.ToString() });
                objParameterList.Add(new ParameterList { ParameterName = "_symbol", ParameterValue = Convert.ToString(objStockTransactionsEntiry.Symbol) });
                objParameterList.Add(new ParameterList { ParameterName = "_typeID", ParameterValue = Convert.ToString(objStockTransactionsEntiry.TypeID) });
                objParameterList.Add(new ParameterList { ParameterName = "_brokerageCompanyName", ParameterValue = objStockTransactionsEntiry.BrokerageCompanyName });
                objParameterList.Add(new ParameterList { ParameterName = "_date", ParameterValue = objStockTransactionsEntiry.Date.ToDateTimeFormat() });
                objParameterList.Add(new ParameterList { ParameterName = "_shares", ParameterValue = Convert.ToString(objStockTransactionsEntiry.Shares) });
                objParameterList.Add(new ParameterList { ParameterName = "_price", ParameterValue = Convert.ToString(objStockTransactionsEntiry.Price) });
                objParameterList.Add(new ParameterList { ParameterName = "_commission", ParameterValue = Convert.ToString(objStockTransactionsEntiry.Commmission) });
                objParameterList.Add(new ParameterList { ParameterName = "_notes", ParameterValue = objStockTransactionsEntiry.Notes });
                objParameterList.Add(new ParameterList { ParameterName = "_IsActive", ParameterValue = objStockTransactionsEntiry.IsActive ? "1" : "0" });
                objParameterList.Add(new ParameterList { ParameterName = "_IsDeleted", ParameterValue = objStockTransactionsEntiry.IsDeleted ? "1" : "0" });

                status = objDBAccess.ExecuteStoreProcedure("SetStockTransactions", objParameterList);
                return status;
            }
            catch (Exception ex)
            {
                return status;
                throw ex;
            }
        }


        public bool SetRSUDetails(RSUEntity objRSUEntity)
        {
            bool status = false;
            try
            {
                List<ParameterList> objParameterList = new List<ParameterList>();
                objParameterList.Add(new ParameterList { ParameterName = "_RSUID", ParameterValue = objRSUEntity.RSUID.ToString() });
                objParameterList.Add(new ParameterList { ParameterName = "_UserID", ParameterValue = objRSUEntity.UserID.ToString() });
                objParameterList.Add(new ParameterList { ParameterName = "_GrantDate", ParameterValue = objRSUEntity.GrantDate.ToDateTimeFormat() });
                objParameterList.Add(new ParameterList { ParameterName = "_FMVonVestDate", ParameterValue = objRSUEntity.FMVonVestDate.ToString() });
                objParameterList.Add(new ParameterList { ParameterName = "_FMVonGrantDate", ParameterValue = objRSUEntity.FMVonGrantDate.ToString() });
                objParameterList.Add(new ParameterList { ParameterName = "_SharesVested", ParameterValue = objRSUEntity.SharesVested.ToString() });
                objParameterList.Add(new ParameterList { ParameterName = "_SharesGranted", ParameterValue = objRSUEntity.SharesGranted.ToString() });
                objParameterList.Add(new ParameterList { ParameterName = "_TaxPaidatVest", ParameterValue = objRSUEntity.TaxPaidatVest.ToString() });
                objParameterList.Add(new ParameterList { ParameterName = "_VestDate", ParameterValue = objRSUEntity.VestDate.ToDateTimeFormat() });
                objParameterList.Add(new ParameterList { ParameterName = "_SellableShares", ParameterValue = objRSUEntity.SellableShares.ToString() });
                objParameterList.Add(new ParameterList { ParameterName = "_IsActive", ParameterValue = objRSUEntity.IsActive ? "1" : "0" });
                objParameterList.Add(new ParameterList { ParameterName = "_IsDeleted", ParameterValue = objRSUEntity.IsDeleted ? "1" : "0" });
                objParameterList.Add(new ParameterList { ParameterName = "_BrokerageCompanyName", ParameterValue = objRSUEntity.BrokerageCompanyName.ToString() });
                objParameterList.Add(new ParameterList { ParameterName = "_symbol", ParameterValue = objRSUEntity.Symbol.ToString() }); 

                status = objDBAccess.ExecuteStoreProcedure("SETRSU", objParameterList);
                return status;
            }
            catch (Exception ex)
            {
                return status;
                throw ex;
            }
        }

        public List<RSUEntity> GetRSUDetails(int userID)
        {
            try
            {
                List<ParameterList> objParameterList = new List<ParameterList>();
                objParameterList.Add(new ParameterList { ParameterName = "_userID", ParameterValue = userID.ToString() });
                DataTable dt = objDBAccess.GetStoreProcedureDataTable("GetRSUDetailsByUserID", objParameterList);
                if (dt.Rows.Count > 0)
                {
                    List<RSUEntity> objRSUEntity = new List<RSUEntity>();
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {

                        objRSUEntity.Add(new RSUEntity
                        {
                            RSUID = Convert.ToInt32(dt.Rows[i]["RSUID"]),
                            UserID = Convert.ToInt32(dt.Rows[i]["UserID"]),
                            GrantDate = DateTime.Parse(Convert.ToString(dt.Rows[i]["GrantDate"])),
                            FMVonVestDate = Convert.ToDecimal(Convert.ToString(dt.Rows[i]["FMVonVestDate"])),
                            FMVonGrantDate = Convert.ToDecimal(Convert.ToString(dt.Rows[i]["FMVonGrantDate"])),
                            SharesVested = Convert.ToInt32(dt.Rows[i]["SharesVested"]),
                            SharesGranted = Convert.ToInt32(dt.Rows[i]["SharesGranted"]),
                            TaxPaidatVest = Convert.ToDecimal(dt.Rows[i]["TaxPaidatVest"]),
                            VestDate = DateTime.Parse(Convert.ToString(dt.Rows[i]["VestDate"])),
                            SellableShares = Convert.ToInt32(dt.Rows[i]["SellableShares"]),
                            CreatedDate = DateTime.Parse(Convert.ToString(dt.Rows[i]["CreatedDate"])),
                            //ModifiedDate = DateTime.Parse(Convert.ToString(dt.Rows[i]["ModifiedDate"])),
                            BrokerageCompanyName = Convert.ToString(dt.Rows[i]["BrokerageCompanyName"]),
                            Symbol = Convert.ToString(dt.Rows[i]["Symbol"])

                        });


                    }
                    return objRSUEntity;
                }
                else
                {
                    return null;
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool SetESPPDetails(ESPPEntity objESPPEntity)
        {
            bool status = false;
            try
            {
                List<ParameterList> objParameterList = new List<ParameterList>();
                objParameterList.Add(new ParameterList { ParameterName = "_ESPPID", ParameterValue = objESPPEntity.ESPPID.ToString() });
                objParameterList.Add(new ParameterList { ParameterName = "_UserID", ParameterValue = objESPPEntity.UserID.ToString() });
                objParameterList.Add(new ParameterList { ParameterName = "_GrantDate", ParameterValue = objESPPEntity.GrantDate.ToDateTimeFormat() });
                objParameterList.Add(new ParameterList { ParameterName = "_PurchaseDate", ParameterValue = objESPPEntity.PurchaseDate.ToDateTimeFormat() });
                objParameterList.Add(new ParameterList { ParameterName = "_Discount", ParameterValue = objESPPEntity.Discount.ToString() });
                objParameterList.Add(new ParameterList { ParameterName = "_SharedPurchases", ParameterValue = objESPPEntity.SharedPurchases.ToString() });
                objParameterList.Add(new ParameterList { ParameterName = "_SharesPurchased", ParameterValue = objESPPEntity.SharesPurchased.ToString() });
                objParameterList.Add(new ParameterList { ParameterName = "_PurchsePrice", ParameterValue = objESPPEntity.PurchsePrice.ToString() });
                objParameterList.Add(new ParameterList { ParameterName = "_IsActive", ParameterValue = objESPPEntity.IsActive ? "1" : "0" });
                objParameterList.Add(new ParameterList { ParameterName = "_IsDeleted", ParameterValue = objESPPEntity.IsDeleted ? "1" : "0" });
                objParameterList.Add(new ParameterList { ParameterName = "_BrokerageCompanyName", ParameterValue = objESPPEntity.BrokerageCompanyName.ToString() });
                objParameterList.Add(new ParameterList { ParameterName = "_symbol", ParameterValue = objESPPEntity.Symbol.ToString() });
                objParameterList.Add(new ParameterList { ParameterName = "_FMVonPurchaseDate", ParameterValue = objESPPEntity.FMVonPurchaseDate.ToString() });
                objParameterList.Add(new ParameterList { ParameterName = "_FMVonGrantDate", ParameterValue = objESPPEntity.FMVonGrantDate.ToString() });
                status = objDBAccess.ExecuteStoreProcedure("SETESPP", objParameterList);
                return status;
            }
            catch (Exception ex)
            {
                return status;
                throw ex;
            }
        }

        public List<ESPPEntity> GetESPPDetails(int userID)
        {
            try
            {
                List<ParameterList> objParameterList = new List<ParameterList>();
                objParameterList.Add(new ParameterList { ParameterName = "_userID", ParameterValue = userID.ToString() });
                DataTable dt = objDBAccess.GetStoreProcedureDataTable("GetESPPDetailsByUserID", objParameterList);
                if (dt.Rows.Count > 0)
                {
                    List<ESPPEntity> objESPPEntity = new List<ESPPEntity>();
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        objESPPEntity.Add(new ESPPEntity
                        {
                            ESPPID = Convert.ToInt32(dt.Rows[i]["ESPPID"]),
                            UserID = Convert.ToInt32(dt.Rows[i]["UserID"]),
                            GrantDate = DateTime.Parse(Convert.ToString(dt.Rows[i]["GrantDate"])),
                            PurchaseDate = DateTime.Parse(Convert.ToString(dt.Rows[i]["PurchaseDate"])),
                            Discount = Convert.ToInt32(dt.Rows[i]["Discount"]),
                            SharedPurchases = Convert.ToInt32(dt.Rows[i]["SharedPurchases"]),
                            SharesPurchased = Convert.ToInt32(dt.Rows[i]["SharesPurchased"]),
                            PurchsePrice = Convert.ToDecimal(dt.Rows[i]["PurchsePrice"]),
                            CreatedDate = DateTime.Parse(Convert.ToString(dt.Rows[i]["CreatedDate"])),
                            //ModifiedDate = DateTime.Parse(Convert.ToString(dt.Rows[i]["ModifiedDate"])),
                            BrokerageCompanyName = Convert.ToString(dt.Rows[i]["BrokerageCompanyName"]),
                            Symbol = Convert.ToString(dt.Rows[i]["Symbol"]),
                            FMVonPurchaseDate = Convert.ToDecimal(Convert.ToString(dt.Rows[i]["FMVonPurchaseDate"])),
                            FMVonGrantDate = Convert.ToDecimal(Convert.ToString(dt.Rows[i]["FMVonGrantDate"]))
                        });
                    }
                    return objESPPEntity;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}
