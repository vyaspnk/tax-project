﻿using BusinessLayer.BusinessObjects;
using BusinessLayer.DataBase;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer
{
    /// <summary>
    /// 
    /// </summary>
    public class Calc401KDao
    {
        private DBAccess objDBAccess = DBAccess.Instance;

        public List<Calc401Entity> GetCalc401DetailsBYID(int UserID)
        {
            try
            {
                List<ParameterList> objParameterList = new List<ParameterList>();
                objParameterList.Add(new ParameterList { ParameterName = "_UserID", ParameterValue = UserID.ToString() });
                DataTable dt = objDBAccess.GetStoreProcedureDataTable("GetCalc401DetailsBYID", objParameterList);
                if (dt.Rows.Count > 0)
                {
                    List<Calc401Entity> objCalc401EntityList = new List<Calc401Entity>();
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {

                        objCalc401EntityList.Add(new Calc401Entity
                                                    {
                                                        ChartGUID = Convert.ToInt32(dt.Rows[i]["ChartGUID"]),
                                                        UserID = Convert.ToInt32(dt.Rows[i]["UserID"]),
                                                        HowManyYearToRetire = Convert.ToInt32(dt.Rows[i]["HowManyYearToRetire"]),
                                                        EmployerContributionPercentage = Convert.ToInt32(dt.Rows[i]["EmployerContributionPercentage"]),
                                                        EmpContribution = Convert.ToInt32(dt.Rows[i]["EmpContribution"]),
                                                        Salary = Convert.ToDecimal(dt.Rows[i]["Salary"]),
                                                        GainPercent = Convert.ToInt32(dt.Rows[i]["GainPercent"]),
                                                        IsMaster = Convert.ToBoolean(dt.Rows[i]["IsMaster"]),
                                                        CalType = Convert.ToString(dt.Rows[i]["CalType"]),
                                                        CurrentSavings = Convert.ToDecimal(dt.Rows[i]["CurrentSavings"])
                                                    });
                        //objCalc401Entity.ChartGUID = Convert.ToInt32(dt.Rows[0]["ChartGUID"]);
                        //objCalc401Entity.UserID = Convert.ToInt32(dt.Rows[0]["UserID"]);
                        //objCalc401Entity.HowManyYearToRetire = Convert.ToInt32(dt.Rows[0]["HowManyYearToRetire"]);
                        //objCalc401Entity.EmployerContributionPercentage = Convert.ToInt32(dt.Rows[0]["EmployerContributionPercentage"]);
                        //objCalc401Entity.EmpContribution = Convert.ToInt32(dt.Rows[0]["EmpContribution"]);
                        //objCalc401Entity.Salary = Convert.ToDecimal(dt.Rows[0]["Salary"]);
                        //objCalc401Entity.GainPercent = Convert.ToInt32(dt.Rows[0]["GainPercent"]);
                        //objCalc401Entity.IsMaster = Convert.ToBoolean(dt.Rows[0]["IsMaster"]);
                    }
                    return objCalc401EntityList;
                }
                else
                {
                    return null;
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public bool Set401KCalCulatorDetails(Calc401Entity objCalc401Entity)
        {
            bool status = false;
            try
            {
                List<ParameterList> objParameterList = new List<ParameterList>();

                objParameterList.Add(new ParameterList { ParameterName = "_ChartGUID", ParameterValue = objCalc401Entity.ChartGUID.ToString() });
                objParameterList.Add(new ParameterList { ParameterName = "_UserID", ParameterValue = objCalc401Entity.UserID.ToString() });
                objParameterList.Add(new ParameterList { ParameterName = "_HowManyYearToRetire", ParameterValue = Convert.ToString(objCalc401Entity.HowManyYearToRetire) });
                objParameterList.Add(new ParameterList { ParameterName = "_EmployerContributionPercentage", ParameterValue = Convert.ToString(objCalc401Entity.EmployerContributionPercentage) });
                objParameterList.Add(new ParameterList { ParameterName = "_EmpContribution", ParameterValue = Convert.ToString(objCalc401Entity.EmpContribution) });
                objParameterList.Add(new ParameterList { ParameterName = "_Salary", ParameterValue = Convert.ToString(objCalc401Entity.Salary) });
                objParameterList.Add(new ParameterList { ParameterName = "_GainPercent", ParameterValue = Convert.ToString(objCalc401Entity.GainPercent) });
                objParameterList.Add(new ParameterList { ParameterName = "_IsActive", ParameterValue = objCalc401Entity.IsActive ? "1" : "0" });
                objParameterList.Add(new ParameterList { ParameterName = "_IsDeleted", ParameterValue = objCalc401Entity.IsDeleted ? "1" : "0" });
                objParameterList.Add(new ParameterList { ParameterName = "_IsMaster", ParameterValue = objCalc401Entity.IsMaster ? "1" : "0" });
                objParameterList.Add(new ParameterList { ParameterName = "_CalType", ParameterValue = objCalc401Entity.CalType });
                objParameterList.Add(new ParameterList { ParameterName = "_CurrentSavings", ParameterValue = Convert.ToString(objCalc401Entity.CurrentSavings) });


                status = objDBAccess.ExecuteStoreProcedure("Set401KCalCulatorDetails", objParameterList);
                return status;
            }
            catch (Exception ex)
            {
                return status;
                throw ex;
            }
        }
    }
}
