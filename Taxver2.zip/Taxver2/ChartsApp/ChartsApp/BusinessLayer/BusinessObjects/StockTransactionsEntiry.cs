﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.BusinessObjects
{
    /// <summary>
    /// 
    /// </summary>
    public class StockTransactionsEntity
    {
        /// <summary>
        /// 
        /// </summary>
        public int StockTransactionsID { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public int UserID { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string Symbol { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public int TypeID { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string TransactionType { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public DateTime Date { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public decimal Shares { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public decimal Price { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public decimal Commmission { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string Notes { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public DateTime CreatedDate { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public DateTime ModifiedDate { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public bool IsActive { get; set; }
        
        /// <summary>
        /// 
        /// </summary>
        public bool IsDeleted { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string BrokerageCompanyName { get; set; }

    }

    /// <summary>
    /// 
    /// </summary>
    public class RSUEntity
    {
        public int RSUID { get; set; }
        public int UserID { get; set; }
        public DateTime GrantDate { get; set; }
        public decimal FMVonVestDate { get; set; }
        public decimal FMVonGrantDate { get; set; }
        public int SharesVested { get; set; }
        public int SharesGranted { get; set; }
        public decimal TaxPaidatVest { get; set; }
        public DateTime VestDate { get; set; }
        public int SellableShares { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime ModifiedDate { get; set; }
        public bool IsActive { get; set; }
        public bool IsDeleted { get; set; }
        public string BrokerageCompanyName { get; set; }

        public string Symbol { get; set; }

    }

    /// <summary>
    /// 
    /// </summary>
    public class ESPPEntity
    {
        public int ESPPID { get; set; }
        public int UserID { get; set; }
        public DateTime GrantDate { get; set; }
        public DateTime PurchaseDate { get; set; }
        public decimal Discount { get; set; }
        public int SharedPurchases { get; set; }
        public int SharesPurchased { get; set; }
        public decimal PurchsePrice { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime ModifiedDate { get; set; }
        public bool IsActive { get; set; }
        public bool IsDeleted { get; set; }
        public string BrokerageCompanyName { get; set; }

        public string Symbol { get; set; }
        public decimal FMVonPurchaseDate { get; set; }
        public decimal FMVonGrantDate { get; set; }
    }
}
