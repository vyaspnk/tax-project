﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.BusinessObjects
{
    /// <summary>
    /// 
    /// </summary>
    public class BankDetailsEntity
    {
        public int UserBankDetailsID { get; set; }
        public int UserID { get; set; }
        public string BankName { get; set; }
        public string AccountName { get; set; }
        public decimal AccountBalance { get; set; }        
        public int Type { get; set; }
        public DateTime ModifiedDate { get; set; }
        public bool IsActive { get; set; }        
    }
}
