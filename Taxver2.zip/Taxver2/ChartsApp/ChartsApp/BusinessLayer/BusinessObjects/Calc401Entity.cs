﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.BusinessObjects
{
    /// <summary>
    /// 
    /// </summary>
    public class Calc401Entity
    {
        public int ChartGUID { get; set; }
        public int UserID { get; set; }
        public int HowManyYearToRetire { get; set; }
        public int EmployerContributionPercentage { get; set; }
        public int EmpContribution { get; set; }
        public decimal Salary { get; set; }
        public int GainPercent { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime ModifiedDate { get; set; }
        public bool IsActive { get; set; }
        public bool IsDeleted { get; set; }

        public bool IsMaster { get; set; }

        public string CalType { get; set; }

        public decimal CurrentSavings { get; set; }
    }
}
