﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.BusinessObjects
{
    /// <summary>
    /// 
    /// </summary>
    public class User401kDetailsEntity
    {
        public int User401kDetailsID { get; set; }
        public int UserID { get; set; }
        public int CurrentContributionPersentage { get; set; }
        public decimal Current401kBalance { get; set; }
        public int EmployerMatchPersentage { get; set; }
        public int EmployerMatchEndPersentage { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime ModifiedDate { get; set; }
        public bool IsActive { get; set; }
        public bool IsDeleted { get; set; }
    }
}
