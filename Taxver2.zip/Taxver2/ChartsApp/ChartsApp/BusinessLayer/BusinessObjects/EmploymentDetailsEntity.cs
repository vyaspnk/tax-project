﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.BusinessObjects
{
    /// <summary>
    /// 
    /// </summary>
    public class EmploymentDetailsEntity
    {
        public int EmploymentDetailsID { get; set; }
        public int UserID { get; set; }
        public string CompanyName { get; set; }
        public decimal GrossPay { get; set; }
        public decimal Bonus { get; set; }
        public int PayFrequencyID { get; set; }
        public DateTime EmpStartDate { get; set; }
        public DateTime EmpEndDate { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime ModifiedDate { get; set; }
        public bool IsActive { get; set; }
        public bool IsDeleted { get; set; }
    }
}
