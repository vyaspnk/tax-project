﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer
{
    public static class Utilities
    {
        public static string ToDateTimeFormat(this DateTime dt)
        {
            return dt.Add(DateTime.Now.TimeOfDay).ToString("yyyy-MM-dd HH:mm:ss");
        }
    }
}
