﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.DataBase
{
    /// <summary>
    /// 
    /// </summary>
    class DBAccess
    {
        /// <summary>
        /// 
        /// </summary>
        static readonly DBAccess _instance = new DBAccess();

        /// <summary>
        /// 
        /// </summary>
        public static DBAccess Instance
        {
            get
            {
                return _instance;
            }
        }

        public DataTable GetStoreProcedureDataTable(string sql, List<ParameterList> listParameter)
        {
            DataTable objDataTable = new DataTable();
            MySqlConnection mySqlConnectionString = new MySqlConnection(ConfigurationManager.ConnectionStrings["MySQLConnectionString"].ToString());

            try
            {
                using (MySqlDataAdapter adapterDataTable = new MySqlDataAdapter(sql, mySqlConnectionString))
                {
                    adapterDataTable.SelectCommand.CommandType = CommandType.StoredProcedure;

                    foreach (var item in listParameter)
                    {
                        adapterDataTable.SelectCommand.Parameters.Add(new MySqlParameter(item.ParameterName, item.ParameterValue));
                    }

                    adapterDataTable.Fill(objDataTable);
                    adapterDataTable.Dispose();
                    return objDataTable;
                }
            }
            catch
            {
                throw;
            }
            finally
            {
                mySqlConnectionString.Dispose();
                objDataTable.Dispose();
            }
        }

        public bool ExecuteStoreProcedure(string sql, List<ParameterList> listParameter)
        {
            bool status = false;
            MySqlConnection mySqlConnectionString = new MySqlConnection(ConfigurationManager.ConnectionStrings["MySQLConnectionString"].ToString());
            try
            {
                using (MySqlDataAdapter adapter = new MySqlDataAdapter(sql, mySqlConnectionString))
                {
                    adapter.SelectCommand.CommandType = CommandType.StoredProcedure;

                    foreach (var item in listParameter)
                    {
                        
                        adapter.SelectCommand.Parameters.Add(new MySqlParameter(item.ParameterName, item.ParameterValue));
                       

                        

                    }

                    if (mySqlConnectionString.State == ConnectionState.Closed)
                    {
                        mySqlConnectionString.Open();
                    }

                    adapter.SelectCommand.ExecuteNonQuery();

                    if (adapter.SelectCommand.Connection.State == ConnectionState.Open)
                    {
                        adapter.SelectCommand.Connection.Close();
                    }

                    adapter.SelectCommand.Dispose();
                    status = true;
                }
                return status;
            }
            catch (Exception ex)
            {
                //return false;
                throw ex;
            }
            finally
            {
                mySqlConnectionString.Dispose();
            }
        }
    }

}
