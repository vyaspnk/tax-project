CREATE TABLE Users (
UserID UniqueIdentifier not null DEFAULT NEWID() primary key,
LoginID varchar(50) not null unique,
LoginPassword varchar(200) not null,
Email varchar(50),
Phone varchar(15),
CreatedDate Datetime not null default GETDATE(),
ModifiedDate Datetime,
LastLoginDate datetime,
IsActive bit,
IsDeleted bit,
)


